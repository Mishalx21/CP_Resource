1. I almost always use 1-indexing and inclusive ranges unless mentioned otherwise. That means wherever I have used 0-indexing or exclusive ranges I have commented them out explicitly.
2. If you find something wrong, then please create an issue or contact me at https://codeforces.com/profile/YouKn0wWho
