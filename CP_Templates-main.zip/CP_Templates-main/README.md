# CP_Templates
Just a bunch of templates for competetive programming. Will try to maintain this. Please run all code before uploading here.
